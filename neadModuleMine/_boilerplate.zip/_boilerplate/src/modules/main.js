import { Car } from './car.js';

let car = new Car();

console.log(car);
